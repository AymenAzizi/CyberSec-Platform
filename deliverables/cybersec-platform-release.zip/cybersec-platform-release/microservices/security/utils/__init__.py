"""Security service utilities."""
